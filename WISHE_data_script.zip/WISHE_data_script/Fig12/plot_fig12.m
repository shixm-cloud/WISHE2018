% This script replicates Fig. 12 in Shi et al (2018, manuscript under
% review. To run this script the user needs to download the subaxis.m and
% cbrewer.m functions from www.mathworks.com
%
% version hystory
% 06/07/2018: original version  - AFA
clear; clc

addpath /Users/afadames/'Google Drive (angelf.88@gmail.com)'/MATLAB/MATLAB/

fig1 = figure;
a  = 4e7; %circumference of the Earth 
k= 2*pi/a*[0.1:0.05:10]; %zonal wavenumber
k2 = [0.1:0.05:10]; %normalized zonal wavenumnber 
tau = 24*3600; %convective moisture adjustment timescale (1/\alpha)
M = [0. 0.1 0.2];  %normalized gross moist stability (NGMS)

cbar = cbrewer('seq' , 'Reds', 4); %please download cbrewer. generates colors for plot lines

for ii = 1:3
Lu = -9e-8; %WISHE parameter 
c = 50; %gravity wave phase speed
A = k*Lu./tau+1i*M(ii)*k.^2./tau;
% Om = (-A + 1i*A.^2.*k.^-4/c^2)./k.^2./(1+A.^2.*k.^-8./tau.^2/c^4);
for jj = 1:length(k)
    F2 = [tau, 1i, -k(jj)^2*c^2*tau,  ...
        ( -k(jj)*Lu-1i*M(ii).*k(jj)^2 )*c^2  ]; %dispersion relation in polynomial form
    temp = roots(F2);%finds the roots of the dispersion relation
    Om = sort(1i*temp, 'ComparisonMethod', 'real'); % sort the soliution based on the imaginary component
    Om = -1i*Om; 
    om(jj,:) = real(Om); %real component of dispersion
    om2(jj,:) = imag(Om); %imaginary component of dispersion
end

% plots the real component 
ha = subaxis(1,2,1, 'Spacing', 0.06, 'Padding', 0, 'Margin', 0.08); hold on
plot(k2, om(:,1)*24*3600, '-', 'linewidth', 1.25, 'color', cbar(ii+1,:) )
hold on
% 
title(['Frequency (1/day)'],  'Fontsize', 7)
xlabel('Zonal Wavenumber',  'Fontsize', 7)
set(gca,  'Fontsize', 7', 'linewidth', 1, 'TickLength',[0.02 0.02], ...
	'ytick', [0:1:50]/10, 'xtick', [0:1:10])
xlim([0.01 10]); ylim([0 0.5])
axis square
box on
grid on

ha = subaxis(1,2,2, 'Spacing', 0.06, 'Padding', 0,  'Margin', 0.08); hold on
plot(k2, om2(:,1)*24*3600, '-', 'linewidth', 1.25, 'color', cbar(ii+1,:) )
hold on
% 
title(['Growth Rate (1/day)'],  'Fontsize', 7)
xlabel('Zonal Wavenumber',  'Fontsize', 7)
% ylabel('P/Lv (mm/day)',  'Fontsize', 7)
set(gca,  'Fontsize', 7', 'linewidth', 1, 'TickLength',[0.02 0.02], ...
	'ytick', [-20:5:30]/50, 'xtick', [0:1:10])
xlim([0.01 10]); ylim([-0.2 0.25])
axis square
box on
grid on

end 

print('-painters', '-depsc2', '-r500', ['dispersion_moist_wave_GMS'])

return